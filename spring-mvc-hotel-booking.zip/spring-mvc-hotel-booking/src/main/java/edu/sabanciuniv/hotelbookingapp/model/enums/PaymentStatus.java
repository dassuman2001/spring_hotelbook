package edu.sabanciuniv.hotelbookingapp.model.enums;

public enum PaymentStatus {
    PENDING,
    COMPLETED,
    FAILED,
    REFUNDED
}
