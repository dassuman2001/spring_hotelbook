package edu.sabanciuniv.hotelbookingapp.model.enums;

public enum Currency {
    USD,
    EUR,
    TRY
}
