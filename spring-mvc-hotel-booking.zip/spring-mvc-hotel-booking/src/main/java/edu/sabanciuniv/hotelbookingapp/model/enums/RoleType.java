package edu.sabanciuniv.hotelbookingapp.model.enums;

public enum RoleType {

    ADMIN,
    CUSTOMER,
    HOTEL_MANAGER
}
